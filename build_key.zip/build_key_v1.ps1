[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

Add-Type -assembly System.Windows.Forms
Add-Type -AssemblyName PresentationFramework
#Add-Type -AssemblyName PresentationCore


$MinKey				= 16
$Key1				= ""
$Key2				= ""

$StatusLabel			= New-Object System.Windows.Forms.Label
$StatusLabel.Font		= '12pt, style=Bold'


$MainWindow			= New-Object System.Windows.Forms.Form

$ToolTip			= New-Object System.Windows.Forms.ToolTip

$ToolTip.BackColor		= [System.Drawing.Color]::LightGoldenrodYellow
$ToolTip.IsBalloon		= $true

$Key1Button			= New-Object System.Windows.Forms.Button
$Key2Button			= New-Object System.Windows.Forms.Button

$BuildButton			= New-Object System.Windows.Forms.Button
$SaveButton			= New-Object System.Windows.Forms.Button

$Key1BoxStatus			= New-Object System.Windows.Forms.Label
$Key1BoxStatus.ForeColor	='green';
$Key1BoxStatus.Font		= '12pt, style=Bold'
$CKey1BoxStatus			= New-Object System.Windows.Forms.Label
$CKey1BoxStatus.Font		= '12pt, style=Bold'
$Key2BoxStatus			= New-Object System.Windows.Forms.Label
$Key2BoxStatus.ForeColor	='green';
$Key2BoxStatus.Font		= '12pt, style=Bold'
$CKey2BoxStatus			= New-Object System.Windows.Forms.Label
$CKey2BoxStatus.Font		= '12pt, style=Bold'

$Key1Box			= New-Object System.Windows.Forms.TextBox
$Key1Box.PasswordChar		= '*'
$Key1Box.add_TextChanged({if ($Key1Box.Text.length -ge $MinKey){$Key1BoxStatus.Text='OK'} else{$Key1BoxStatus.Text=''};if (($CKey1Box.Text.length -ge $MinKey) -and ($Key1Box.Text -eq $CKey1Box.Text)){$CKey1BoxStatus.Text='Equal';$CKey1BoxStatus.ForeColor='green';$K1OK=$true;} else {$CKey1BoxStatus.Text='Not Equal';$CKey1BoxStatus.ForeColor='red';$K1OK=$false}})

$CKey1Box			= New-Object System.Windows.Forms.TextBox
$CKey1Box.PasswordChar		= '*'
$CKey1Box.add_TextChanged({if (($CKey1Box.Text.length -ge $MinKey) -and ($Key1Box.Text -eq $CKey1Box.Text)){$CKey1BoxStatus.Text='Equal';$CKey1BoxStatus.ForeColor='green';$K1OK=$true}else{$CKey1BoxStatus.Text='Not Equal';$CKey1BoxStatus.ForeColor='red';$K1OK=$false}})

$Key2Box			= New-Object System.Windows.Forms.TextBox
$Key2Box.PasswordChar		= '*'
$Key2Box.add_TextChanged({if ($Key2Box.Text.length -ge $MinKey){$Key2BoxStatus.Text='OK'} else{$Key2BoxStatus.Text=''};if (($CKey2Box.Text.length -ge $MinKey) -and ($Key2Box.Text -eq $CKey2Box.Text)){$CKey2BoxStatus.Text='Equal';$CKey2BoxStatus.ForeColor='green';$K2OK=$true} else{$CKey2BoxStatus.Text='Not Equal';$CKey2BoxStatus.ForeColor='red';$K2OK=$false}})

$CKey2Box			= New-Object System.Windows.Forms.TextBox
$CKey2Box.PasswordChar		= '*'
$CKey2Box.add_TextChanged({if (($CKey2Box.Text.length -ge $MinKey) -and ($Key2Box.Text -eq $CKey2Box.Text)){$CKey2BoxStatus.Text='Equal';$CKey2BoxStatus.ForeColor='green';$K2OK=$true} else{$CKey2BoxStatus.Text='Not Equal';$CKey2BoxStatus.ForeColor='red';$K2OK=$false}})

$Key1BoxLabel			= New-Object System.Windows.Forms.Label
$CKey1BoxLabel			= New-Object System.Windows.Forms.Label
$Key2BoxLabel			= New-Object System.Windows.Forms.Label
$CKey2BoxLabel			= New-Object System.Windows.Forms.Label

$fullkey			= ""

Function LoadKey {
    $Key = ""
    $dlg = New-Object 'Microsoft.Win32.OpenFileDialog'
    $dlg.FileName = "Document" # Default file name
    $dlg.DefaultExt = "" # Default file extension
    $dlg.Filter = "All Files (*.*)|*.*";
    $result = $dlg.ShowDialog()
    if ($result) {
	$Key = Get-Content -Path $dlg.FileName
    }
    return $Key
}


Function BuildKey {
    param ($LKey1, $LKey2)
    $K1 = $LKey1.Trim()+$LKey1.Trim()+$LKey1.Trim()
    $K2 = $LKey2.Trim()+$LKey2.Trim()+$LKey2.Trim()


    if ((($CKey1Box.Text.length -ge $MinKey) -and ($Key1Box.Text -eq $CKey1Box.Text)) -and (($CKey2Box.Text.length -ge $MinKey) -and ($Key2Box.Text -eq $CKey2Box.Text)))
    {

	$CK1 = ""
	$CK2 = ""

	$FCK = ""

	for($i=0; $i -lt $Global:Key1.length ; $i++)
	{
		$CK1 += '{0:x}' -f ([int]([convert]::toint16($Global:Key1[$i],16)) -bxor  [char]([convert]::toint16($K1[$i],16)))
	}
	for($i=0; $i -lt $Global:Key2.length ; $i++)
	{
		$CK2 += '{0:x}' -f ([int]([convert]::toint16($Global:Key2[$i],16)) -bxor  [char]([convert]::toint16($K2[$i],16)))
	}

	for($i=0; $i -lt $CK1.length ; $i++)
	{
		$FCK += '{0:x}' -f ([int]([convert]::toint16($CK1[$i],16)) -bxor  [char]([convert]::toint16($CK2[$i],16)))
	}


	$StatusLabel.Text = "���� ������"
	$StatusLabel.ForeColor = 'green';

	$dlg = New-Object 'Microsoft.Win32.SaveFileDialog'
	$dlg.FileName = "KEY" # Default file name
	$dlg.DefaultExt = "" # Default file extension
	$dlg.Filter = "All Files (*.*)|*.*";
	$result = $dlg.ShowDialog()
	if ($result) {
	    Write-Output $FCK.ToUpper() | out-file -encoding ascii $dlg.FileName
	}
    }
    else
    {
	$StatusLabel.Text = "������ ������� �������"
	$StatusLabel.ForeColor = 'red';
    }

}


# ������� �����
$MainWindow.StartPosition	= "CenterScreen"
$MainWindow.Text		= "Key builder"
$MainWindow.Width		= 415
$MainWindow.Height		= 270
$MainWindow.FormBorderStyle	= 'Fixed3D'
$MainWindow.MaximizeBox		= $false

$Key1Button.Location		= New-Object System.Drawing.Point(20,10)
$Key1Button.Text               = "��������� ����.����������1"
$Key1Button.add_click( { $Global:Key1 = LoadKey; $Key1Button.ForeColor='green';} )
$Key1Button.Autosize           = 1

$Key2Button.Location		= New-Object System.Drawing.Point(200,10)
$Key2Button.Text               = "��������� ����.����������2"
$Key2Button.add_click( { $Global:Key2 = LoadKey; $Key2Button.ForeColor='green'; } )
$Key2Button.Autosize           = 1


$Key1BoxLabel.Location		= New-Object System.Drawing.Point(10,52)
$Key1BoxLabel.Text		= "������ 1"
$Key1BoxLabel.Autosize		= 1

$CKey1BoxLabel.Location		= New-Object System.Drawing.Point(10,82)
$CKey1BoxLabel.Text		= "������ 1(������)"
$CKey1BoxLabel.Autosize		= 1

$Key2BoxLabel.Location		= New-Object System.Drawing.Point(10,113)
$Key2BoxLabel.Text		= "������ 2"
$Key2BoxLabel.Autosize		= 1

$CKey2BoxLabel.Location		= New-Object System.Drawing.Point(10,143)
$CKey2BoxLabel.Text		= "������ 2(������)"
$CKey2BoxLabel.Autosize		= 1


$Key1Box.Location		= New-Object System.Drawing.Point(140,50)
$Key1Box.Width			= 160
$ToolTip.SetToolTip($Key1Box, "������� ������ 1")

$CKey1Box.Location		= New-Object System.Drawing.Point(140,80)
$CKey1Box.Width			= 160
$ToolTip.SetToolTip($CKey1Box, "��������� ���� ������ 1 ��� ��������")

$Key2Box.Location		= New-Object System.Drawing.Point(140,110)
$Key2Box.Width			= 160
$ToolTip.SetToolTip($Key2Box, "������� ������ 2")

$CKey2Box.Location		= New-Object System.Drawing.Point(140,140)
$CKey2Box.Width			= 160
$ToolTip.SetToolTip($CKey2Box, "��������� ���� ������ 2 ��� ��������")


$Key1BoxStatus.Location		= New-Object System.Drawing.Point(310,50)
$CKey1BoxStatus.Location	= New-Object System.Drawing.Point(310,80)
$Key2BoxStatus.Location		= New-Object System.Drawing.Point(310,110)
$CKey2BoxStatus.Location	= New-Object System.Drawing.Point(310,140)


$StatusLabel.Location		= New-Object System.Drawing.Point(20,170)
#$StatusLabel.Text		= "���� 2"
$StatusLabel.Autosize		= 1


$BuildButton.Location		= New-Object System.Drawing.Point(30,200)
$BuildButton.Text               = "������� � ��������� ����"

$BuildButton.add_click( { BuildKey $Key1Box.Text $Key2Box.Text } )
$BuildButton.Autosize           = 1


$SaveButton.Location          = New-Object System.Drawing.Point(250,200)
$SaveButton.Text              = "�����"
$SaveButton.add_click({ $MainWindow.Close() })
$SaveButton.Autosize          = 1


$MainWindow.Controls.Add($Key1Button)
$MainWindow.Controls.Add($Key2Button)

$MainWindow.Controls.Add($BuildButton)
$MainWindow.Controls.Add($SaveButton)

$MainWindow.Controls.Add($Key1Box)
$MainWindow.Controls.Add($CKey1Box)
$MainWindow.Controls.Add($Key2Box)
$MainWindow.Controls.Add($CKey2Box)

$MainWindow.Controls.Add($Key1BoxLabel)
$MainWindow.Controls.Add($CKey1BoxLabel)
$MainWindow.Controls.Add($Key2BoxLabel)
$MainWindow.Controls.Add($CKey2BoxLabel)

$MainWindow.Controls.Add($Key1BoxStatus)
$MainWindow.Controls.Add($CKey1BoxStatus)
$MainWindow.Controls.Add($Key2BoxStatus)
$MainWindow.Controls.Add($CKey2BoxStatus)

$MainWindow.Controls.Add($StatusLabel)


$MainWindow.ShowDialog() | Out-Null
