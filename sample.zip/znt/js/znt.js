var SETUP = {		
	'TERMINAL': '60106914',
	'COUNTRY': '643',
	'LANG': 'ru',
	'CURRENCY': 'RUB',
	'TRTYPE': '1',
	'EMAIL': 'b.borodin@zenit.ru',
	'BACKREF': 'https://shop.ru/zenit/process.php',
	'DESC': 'SHOP',
	'MERCHANT': '60108171',
	'MERCH_NAME': 'SHOP',
	'MERCH_URL': 'https://shop.ru',		
	'SIGN_FIELDS': ['TRTYPE','AMOUNT','TERMINAL','TIMESTAMP','NONCE','CURRENCY','ORDER'],
	'KEY': '8D8FBA028BF58AACB9D7B0CE330E684C',
	'ALGO': 'SHA-1'
};

function makeNonce() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (var i = 0; i < 32; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  return text;
}

function InitForm()
{			
	// SETUP
	$("#TERMINAL").val(SETUP.TERMINAL);
	$("#MERCHANT").val(SETUP.MERCHANT);
	$("#COUNTRY").val(SETUP.COUNTRY);
	$("#LANG").val(SETUP.LANG);	
	$("#TRTYPE").val(SETUP.TRTYPE);	
	$("#DESC").val(SETUP.DESC);	
	$("#MERCH_NAME").val(SETUP.MERCH_NAME);	
	$("#MERCH_URL").val(SETUP.MERCH_URL);		
	$("#CURRENCY").val(SETUP.CURRENCY);	
	$("#BACKREF").val(SETUP.BACKREF);
	$("#EMAIL").val(SETUP.EMAIL);
		
	// DYNAMIC
	var ordr = moment().format('YYYYMMDDHHmmssSSS');
	var tmstmp = moment.utc().format('YYYYMMDDHHmmss');
	console.log("timestamp: " + tmstmp);
	var nonce = makeNonce();
	var min=1; 
	var max=20;  
	var random_amount = (Math.random() * (+max - +min) + +min).toFixed(2); 	
	
	$("#AMNT").html(random_amount);
	$("#AMOUNT").val(random_amount);
	$("#ORDER").val(ordr);
	$("#NONCE").val(ordr+"001");	
	$("#TIMESTAMP").val(tmstmp);
		
	// TAKE FIELDS FROM SIGN_FIELDS
	UpdateSign();	
	
	// SUBSCRIBE EVENTS
	$("#AMOUNT").on('input', () => UpdateSign());
	$("#TRTYPE").on('input', () => UpdateSign());
	$("#NONCE").on('input', () => UpdateSign());
	$("#ORDER").on('input', () => UpdateSign());
	$("#TERMINAL").on('input', () => UpdateSign());
	$("#MERCHANT").on('input', () => UpdateSign());
	$("#MERCH_URL").on('input', () => UpdateSign());
	$("#MERCH_NAME").on('input', () => UpdateSign());
	$("#CURRENCY").on('input', () => updateSign());
	$("#DESC").on('input', () => UpdateSign());
	$("#LANG").on('input', () => UpdateSign());
	$("#DESK").on('input', () => UpdateSign());
	$("#COUNTRY").on('input', () => UpdateSign());
}

function UpdateSign() {
	var text = GetSignText();
	console.log("string: " + text);
	var p_sign = CalcHMAC(text);
	console.log("p_sing: " + p_sign);
	$("#P_SIGN").val(p_sign);
}

function GetSignText() {
	var result = '';
	var fildsLength = SETUP.SIGN_FIELDS.length;
    for (var i = 0; i < fildsLength; i++) {
        console.log(SETUP.SIGN_FIELDS[i]);
        var ss = $("#"+SETUP.SIGN_FIELDS[i]).val();
		result = result + ss.length + ss;
    }
	return result;
}

function CalcHMAC(text) {
	var hmacOutput = '';
	try {				
		var hmacKey = SETUP.KEY;
		var hmacObj = new jsSHA(SETUP.ALGO,'TEXT');
		hmacObj.setHMACKey(hmacKey,'HEX');
		hmacObj.update(text);
		hmacOutput = hmacObj.getHMAC('HEX');
	} catch(e) {
		hmacOutput = e.message;
		console.error(e.message);
	}
	return hmacOutput;
}